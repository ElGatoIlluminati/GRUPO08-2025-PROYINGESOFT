from django.db import models

class Boletin(models.Model):
    RECETA_TYPE_CHOICES = (
        (1, 'Cambio climático'),
        (2, 'Gestión de recursos'),
        (3, 'Sistemas alimentarios'),
    )

    titulo = models.CharField(max_length=255)
    descripcion = models.TextField()
    receta_foto = models.ImageField(upload_to='boletines/')
    receta_type = models.IntegerField(choices=RECETA_TYPE_CHOICES)
    fecha = models.DateField()

    def __str__(self):
        return self.titulo

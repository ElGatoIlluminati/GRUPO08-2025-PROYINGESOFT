from django import forms
from .models import Boletin

class BoletinForm(forms.ModelForm):
    class Meta:
        model = Boletin
        fields = ['titulo', 'descripcion', 'receta_foto', 'receta_type']  # Ajusta según los campos de tu modelo

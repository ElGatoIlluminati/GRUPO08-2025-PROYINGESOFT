from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from .views import ver_boletin

urlpatterns = [
    path('', views.home, name='home'),
    path('boletines/', views.boletines, name='boletines'),
    path('boletines/<int:id>/', views.boletin_detalle, name='boletin_detalle'),
    path('login/', views.login_view, name='login'),
    path('perfil/', views.perfil, name='perfil'),
    path('perfil/modificar/', views.perfil_modificar, name='perfil_modificar'),
    path('perfil/eliminar/', views.user_delete, name='user_delete'),
    path('ver_boletin/<int:boletin_id>/', views.ver_boletin, name='ver_boletin'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('boletines/editar/<int:pk>/', views.editar_boletin, name='editar_boletin'),
    path('register/', views.register_view, name='register'),

    path('descargar_boletin/<int:boletin_id>/', views.descargar_boletin_pdf, name='exportar_pdf'),
    path('enviar/email/', views.enviar_boletin_por_correo, name='enviar_email'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
import os
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404
from django.contrib.auth import get_user_model
from datetime import datetime
from .models import Boletin
from django.shortcuts import redirect
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.models import User
from django.http import FileResponse
from django.conf import settings
from .forms import BoletinForm 
from django.db.models import Q
from .models import UserProfile
from .forms import RegisterForm
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse, JsonResponse

# Ocupé estos para la exportación de boletines
from xhtml2pdf import pisa
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
from io import BytesIO
#----------------------


User = get_user_model()

# Página de inicio
def home(request):
    return render(request, 'home.html')


# Vista para la sección de boletines
def boletines(request):
    return render(request, 'boletines.html')


# Vista para login
@csrf_exempt
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('pwd')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Inicio de sesión exitoso")
            return redirect('home')
        else:
            # Agrega un mensaje de error y vuelve a renderizar
            messages.error(request, "Nombre de usuario o contraseña incorrectos.")

    return render(request, 'login.html')  # Ya sea GET o POST fallido


# Vista para el perfil de usuario (requiere estar autenticado)
@login_required
def perfil(request):
    return render(request, 'perfil.html')


# Vista para cerrar sesión
def custom_logout(request):
    logout(request)
    messages.success(request, "Has cerrado sesión exitosamente.")
    return redirect('home')  # Redirige a la página de inicio

def perfil_view(request):
    usuario = request.user  # Obtén el usuario autenticado
    context = {
        'nombre_usuario': usuario.get_full_name(),
        'tipo_usuario': 'Administrador',  # Cambia según el rol del usuario
        'correo': usuario.email,
        'ultima_fecha_sesion': usuario.last_login.date() if usuario.last_login else 'Nunca',
        'ultima_hora_sesion': usuario.last_login.time() if usuario.last_login else 'Nunca',
    }
    return render(request, 'perfil.html', context)

def boletines(request):
    # Filtros
    boletines = Boletin.objects.all()

    # Filtro por tema
    temas = request.GET.get('temas')
    if temas:
        try:
            temas = int(temas)  # Convertimos el valor a un entero
            boletines = boletines.filter(receta_type=temas)
        except ValueError:
            # Si no se puede convertir a entero, no aplicar el filtro
            pass

    # Filtro por fecha
    fecha_desde = request.GET.get('fecha_desde')
    fecha_hasta = request.GET.get('fecha_hasta')
    if fecha_desde:
        boletines = boletines.filter(fecha__gte=fecha_desde)
    if fecha_hasta:
        boletines = boletines.filter(fecha__lte=fecha_hasta)

    # Filtro por título
    titulo = request.GET.get('titulo')  # Obtiene el parámetro 'titulo' de la URL
    if titulo:
        boletines = boletines.filter(titulo__icontains=titulo)  # Busca coincidencias parciales

    # Enviar los datos filtrados a la plantilla
    return render(request, 'boletines.html', {
        'boletines': boletines,  # Lista de boletines filtrados
        'temas': temas,          # Tema seleccionado (si existe)
        'fecha_desde': fecha_desde,  # Fecha inicial seleccionada
        'fecha_hasta': fecha_hasta,  # Fecha final seleccionada
        'titulo': titulo,        # Título ingresado para búsqueda
    })

@login_required
def editar_boletin(request, pk):
    boletin = get_object_or_404(Boletin, pk=pk)  # Obtén el boletín por su ID (pk)

    if request.method == 'POST':  # Si el usuario envió datos
        form = BoletinForm(request.POST, request.FILES, instance=boletin)  # Incluye el archivo si corresponde
        if form.is_valid():  # Valida el formulario
            form.save()  # Guarda los cambios
            return redirect('boletines')  # Redirige a la lista de boletines
    else:
        form = BoletinForm(instance=boletin)  # Muestra el formulario con los datos actuales

    return render(request, 'editar_boletin.html', {'form': form})

def boletines_view(request):
    boletines = Boletin.objects.all()  # O tu filtro si tienes uno
    return render(request, 'boletines.html', {'boletines': boletines})

def boletin_detalle(request, id):
    boletin = get_object_or_404(Boletin, id=id)
    return render(request, 'boletin_detalle.html', {'boletin': boletin})

def boletines_lista(request):
    boletines = Boletin.objects.all()  # Puedes aplicar filtros si lo deseas
    return render(request, 'boletines.html', {'boletines': boletines})

def perfil_modificar(request):
    if request.method == 'POST':
        newusername = request.POST.get('newusername')
        newpwd = request.POST.get('newpwd')
        newpwd2 = request.POST.get('newpwd2')

        if newpwd == newpwd2:
            request.user.username = newusername
            request.user.set_password(newpwd)
            request.user.save()
            update_session_auth_hash(request, request.user)  # Mantén la sesión activa
            return redirect('perfil')
    return redirect('perfil')

def user_delete(request):
    if request.method == 'POST':
        request.user.delete()
        auth_logout(request)  # Cierra la sesión
        return redirect('home')  # Redirige después de eliminar
    return redirect('perfil')

@csrf_exempt
def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password']
            )
            UserProfile.objects.create(user=user, role=form.cleaned_data['role'])
            login(request, user)
            return redirect('home')
        else:
            # Renderizar el formulario con errores y status 400
            return render(request, 'register.html', {'form': form}, status=400)
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})



# -----------------------
# Ver boletín en el navegador (HTML)
# -----------------------

def ver_boletin(request, boletin_id):
    # Ruta al archivo PDF
    archivo_pdf_path = os.path.join(settings.BASE_DIR, 'static', 'pdf', 'boletin_prueba.pdf')
    
    # Mostrar el PDF en el navegador (inline)
    return FileResponse(open(archivo_pdf_path, 'rb'), content_type='application/pdf')


# -----------------------
# Exportar boletín como PDF
# -----------------------

def descargar_boletin_pdf(request, boletin_id):
    # Ruta al archivo PDF
    archivo_pdf_path = os.path.join(settings.BASE_DIR, 'static', 'pdf', 'boletin_prueba.pdf')
    
    # Forzar descarga (attachment)
    response = FileResponse(open(archivo_pdf_path, 'rb'), content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="boletin_prueba.pdf"'
    return response


# -----------------------
# Enviar boletín por correo
# -----------------------

def enviar_boletin_por_correo(request):
    destinatario = request.GET.get('email')

    if not destinatario:
        return HttpResponse("Email requerido", status=400)

    # Ruta absoluta al archivo
    archivo_pdf_path = os.path.join(settings.BASE_DIR, 'static', 'pdf', 'boletin_prueba.pdf')

    if not os.path.exists(archivo_pdf_path):
        return HttpResponse("Archivo no encontrado", status=404)

    with open(archivo_pdf_path, 'rb') as pdf_file:
        email = EmailMessage(
            subject="Boletín Estratégico VIGIFIA",
            body="Hola,\n\nAdjuntamos el boletín estratégico solicitado.\n\nSaludos cordiales,\nEquipo VIGIFIA",
            from_email="grupo8ingesoftvigifia@gmail.com",
            to=[destinatario],
        )
        email.attach("boletin_prueba.pdf", pdf_file.read(), "application/pdf")
        email.send()

    return HttpResponse("Correo enviado correctamente")
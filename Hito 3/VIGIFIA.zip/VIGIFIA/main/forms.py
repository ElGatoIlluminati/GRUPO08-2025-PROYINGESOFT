from django import forms
from django.contrib.auth.models import User
from .models import UserProfile
from .models import Boletin
from django.core.validators import RegexValidator, EmailValidator


class BoletinForm(forms.ModelForm):
    class Meta:
        model = Boletin
        fields = ['titulo', 'descripcion', 'receta_foto', 'receta_type']  # Ajusta según los campos de tu modelo


class RegisterForm(forms.ModelForm):
    username = forms.CharField(
        max_length=16,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z0-9.-]+$',
                message='El nombre de usuario solo puede contener letras, números y los caracteres "_", "-", "."'
            )
        ],
        error_messages={
            'required': 'Por favor ingresa un nombre de usuario.',
            'max_length': 'El nombre de usuario no puede tener más de 16 caracteres.'
        }
    )

    email = forms.EmailField(
        error_messages={
            'required': 'El correo electrónico es obligatorio.',
            'invalid': 'El correo electrónico no es válido.'
        }
    )

    password = forms.CharField(
        widget=forms.PasswordInput,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z0-9]+$',
                message='La contraseña solo puede contener letras y números.'
            )
        ],
        error_messages={
            'required': 'Por favor ingresa la contraseña.'
        }
    )

    role = forms.ChoiceField(
        choices=UserProfile.ROLE_CHOICES,
        error_messages={
            'required': 'Debes seleccionar un rol.'
        }
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password']
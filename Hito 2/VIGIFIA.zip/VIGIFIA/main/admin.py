from django.contrib import admin
from .models import Boletin

# Register your models here.

admin.site.register(Boletin)

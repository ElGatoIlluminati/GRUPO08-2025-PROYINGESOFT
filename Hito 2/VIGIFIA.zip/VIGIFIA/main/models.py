from django.contrib.auth.models import User
from django.db import models

class Boletin(models.Model):
    RECETA_TYPE_CHOICES = (
        (1, 'Cambio climático'),
        (2, 'Gestión de recursos'),
        (3, 'Sistemas alimentarios'),
    )

    titulo = models.CharField(max_length=255)
    descripcion = models.TextField()
    receta_foto = models.ImageField(upload_to='boletines/')
    receta_type = models.IntegerField(choices=RECETA_TYPE_CHOICES)
    fecha = models.DateField()

    def __str__(self):
        return self.titulo

class UserProfile(models.Model):
    ROLE_CHOICES = (
        ('lector', 'Lector'),
        ('editor', 'Editor'),
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='lector')

    def __str__(self):
        return f"{self.user.username} - {self.role}"
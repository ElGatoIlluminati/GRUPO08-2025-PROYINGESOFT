from django import forms
from django.contrib.auth.models import User
from .models import UserProfile
from .models import Boletin

class BoletinForm(forms.ModelForm):
    class Meta:
        model = Boletin
        fields = ['titulo', 'descripcion', 'receta_foto', 'receta_type']  # Ajusta según los campos de tu modelo


class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    role = forms.ChoiceField(choices=UserProfile.ROLE_CHOICES)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']